'use strict'

const { utils, logger } = require('@cornerstonesln/tools-nodejs-backend')
const crypto = require('crypto')

const { handleWithError, generateDatetime } = utils

/**
 * Represents the member logic.
 *
 * @class MemberRepository
 */
module.exports = class MemberRepository {
  /**
   * Creates an instance of MemberRepository.
   * @param {mariadb.Pool} connection Database connection object.
   * @memberof MemberRepository
   */
  constructor (connection) {
    this._connection = connection
    this.create = this.create.bind(this)
    this.toDatabase = this.toDatabase.bind(this)
    this.fromDatabase = this.fromDatabase.bind(this)
    this.isEmailExists = this.isEmailExists.bind(this)
    this.isDatabaseNameExists = this.isDatabaseNameExists.bind(this)
  }

  /**
   * Create a new member.
   *
   * @param {*} member Member.
   * @param {*} address Member Address.
   * @param {string} databaseName Database Name.
   * @returns {Promise}
   * @memberof MemberRepository
   */
  async create (member, address, databaseName) {
    let connection
    try {
      // Get a connection from the pool.
      connection = await this._connection.getConnection()

      // Start a new transaction.
      await connection.beginTransaction()

      // Insert a new member.
      const result = await connection.query('INSERT INTO members (member_group_id, email, password, f_name, l_name, join_date, last_login, bid_currency, email_code, parent_id, other_system_reference, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', Object.values(member))
      // Insert member address for member.
      await connection.query('INSERT INTO member_addresses (member_id, company_name, address_google, address, zipcode, city, district, state, state_iso2, country, country_iso2, lat, lng, contactno, fax) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [result.insertId, ...Object.values(address)])
      // Insert member database for member.
      await connection.query('INSERT INTO member_databases (member_id, database_name) VALUES (?, ?)', [result.insertId, databaseName])
      // Create a new database for member.
      // await connection.query('CREATE DATABASE ?? CHARACTER SET utf8 COLLATE utf8_unicode_ci', [databaseName])

      // Commit changes.
      await connection.commit()

      return result.affectedRows > 0 ? this.fromDatabase(member) : null
    } catch (error) {
      logger.e('Unable to create a new member.', error)
      await connection.rollback()
      handleWithError(500, 'Unable to create a new member.')
    } finally {
      // Release (close) the connection.
      if (connection) connection.release()
    }
  }

  /**
   * Check if email exists.
   *
   * @param {string} email Member email.
   * @returns {Promise.<boolean>}
   */
  async isEmailExists (email) {
    let connection
    try {
      // Get a connection from the pool.
      connection = await this._connection.getConnection()

      // Prepare and execute query.
      const stmt = 'SELECT * FROM member WHERE email = ?'
      const data = [email]
      console.log(data)
      const result = await connection.query(stmt, email)

      return !!result.length
    } catch (error) {
      logger.e('Unable to check if email exists.', error)
      handleWithError(500, 'Unable to check if email exists.')
    } finally {
      // Release (close) the connection.
      if (connection) connection.release()
    }
  }

  /**
   * Check if database name exists.
   *
   * @param {string} databaseName Database Name.
   * @returns {Promise.<boolean>}
   */
  async isDatabaseNameExists (databaseName) {
    let connection
    try {
      // Get a connection from the pool.
      connection = await this._connection.getConnection()

      // Prepare and execute query.
      const stmt = 'SELECT * FROM member_databases WHERE database_name = ?'
      const data = [databaseName]
      const result = await connection.query(stmt, data)

      return !!result.length
    } catch (error) {
      logger.e('Unable to check if database name exists.', error)
      handleWithError(500, 'Unable to check if database name exists.')
    } finally {
      // Release (close) the connection.
      if (connection) connection.release()
    }
  }

  /**
   * Converts a member into a data model member.
   *
   * @param {*} member
   * @param {*} parentId
   * @returns
   * @memberof MemberRepository
   */
  toDatabase (member, parentId) {
    return {
      member: {
        member_group_id: member.memberGroupId || 1,
        email: member.email,
        password: member.password,
        f_name: member.fName,
        l_name: member.lName,
        join_date: generateDatetime(),
        last_login: generateDatetime(),
        bid_currency: member.bidCurrency,
        email_code: crypto.createHash('md5').update(member.email).digest('hex'),
        parent_id: parentId,
        other_system_reference: member.otherSystemReference,
        status: 1
      },
      address: {
        company_name: member.companyName,
        address_google: member.origin,
        address: member.address,
        zipcode: member.originPostalCode,
        city: member.originLocality,
        district: member.originSublocalityLevel2,
        state: member.originAdministrativeAreaLevel1,
        state_iso2: member.originAdministrativeAreaLevel1Short,
        country: member.originCountry,
        country_iso2: member.originCountryShort,
        lat: member.originLat,
        lng: member.originLng,
        contactno: member.contactno,
        fax: member.fax
      },
      database_name: member.databaseName
    }
  }

  /**
   * Converts a data model member into a member.
   *
   * @param {*} member
   * @returns
   * @memberof MemberRepository
   */
  fromDatabase (member) {
    return {
      memberGroupId: member.member_group_id,
      email: member.email,
      password: member.password,
      fName: member.f_name,
      lName: member.l_name,
      joinDate: member.join_date,
      bidCurrency: member.bid_currency,
      parentId: member.parent_id,
      otherSystemReference: member.other_system_reference,
      status: member.status
    }
  }
}
