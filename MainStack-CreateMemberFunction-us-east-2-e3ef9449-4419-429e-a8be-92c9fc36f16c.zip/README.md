# Create a new Member

This Lambda Function allows you to create a new member in the database.

| Authorized Member Groups |
|-|
| All. |

| Field | Type | Description | Required Field |
|-|-|-|-|
| email | string | The email address. <br/>**format:** email | required |
| password | string | The password used to login. <br/>**minLength:** 6  | required |
| fName | string | The first name. | required |
| lName | string | The last name. | required |
| bidCurrency | string | The bid currency. | required |
| otherSystemReference | string | The other system reference ID: SAP System Reference ID. | optional |
| companyName | string | The company name. | required |
| origin | string | The address Google. | required |
| address | string | The address. | required |
| originPostalCode | string | The zip code. | required |
| originLocality | string | The city. | required |
| originSublocalityLevel2 | string | The district. | required |
| originAdministrativeAreaLevel1 | string | The state. | required |
| originAdministrativeAreaLevel1Short | string | The state ISO 2. | required |
| originCountry | string | The country. | required |
| originCountryShort | string | The country ISO 2. | required |
| originLat | string | The latitude. | required |
| originLng | string | The longitude. | required |
| contactno | string | The contact number. | required |
| fax | string | The fax number. | optional |
| databaseName | string | The database name. | required |

## Run the tests
1. Read and follow the [prerequisites](/README.md).

1. Install dependencies:

        npm install

1. Run the tests:

        npm test

## Deploy
1. To deploy the function, run:

        zip -r create-member.zip . -x *.env* && aws lambda update-function-code --function-name create-member --zip-file fileb://create-member.zip && rm -r create-member.zip

1. To update the configuration function, run:

        aws lambda update-function-configuration --function-name create-member --timeout 60 --memory-size 256 --environment "Variables={SECRET=string,ALGORITHM=string,RDS_DB_NAME=string,RDS_DB_USER=string,RDS_DB_PASS=string,RDS_DB_HOST=string}" --vpc-config SubnetIds=string,string,SecurityGroupIds=string

To clean up the function, run:

        rm -f package-lock.json && rm -rf node_modules
