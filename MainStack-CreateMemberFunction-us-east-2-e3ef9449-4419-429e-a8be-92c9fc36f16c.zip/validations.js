'use strict'

const { utils, logger } = require('@cornerstonesln/tools-nodejs-backend')

/**
 * Schema of validations on the request.
 *
 * @const {Object} schema
 */
const schema = {
  title: 'CreateMemberInputModel',
  type: 'object',
  properties: {
    headers: {
      type: 'object',
      properties: {
        'x-healthenviron-request-caller': {
          type: 'string',
          const: 'HealthEnviron-Member'
        },
        'x-healthenviron-api-key': {
          type: 'string',
          pattern:  '^[A-Za-z0-9-_=]+\\.[A-Za-z0-9-_=]+\\.?[A-Za-z0-9-_.+/=]*$'
        }
      },
      errorMessage: {
        required: {
          'x-healthenviron-request-caller': 'Request Caller not provided.',
          'x-healthenviron-api-key': 'API Key not provided.'
        }
      },
      required: ['x-healthenviron-request-caller']
    },
    body: {
      type: 'object',
      allOf: [
        {
          properties: {
            email: { type: 'string', format: 'email' },
            password: { type: 'string', minLength: 6 },
            fName: { type: 'string' },
            lName: { type: 'string' },
            bidCurrency: { type: 'string' },
            otherSystemReference: { type: 'string' },
            companyName: { type: 'string' },
            origin: { type: 'string' },
            address: { type: 'string' },
            originPostalCode: { type: 'string' },
            originLocality: { type: 'string' },
            originSublocalityLevel2: { type: 'string' },
            originAdministrativeAreaLevel1: { type: 'string' },
            originAdministrativeAreaLevel1Short: { type: 'string' },
            originCountry: { type: 'string' },
            originCountryShort: { type: 'string' },
            originLat: { type: 'string' },
            originLng: { type: 'string' },
            contactno: { type: 'string' },
            fax: { type: 'string' },
            databaseName: { type: 'string' }
          }
        }
      ],
      errorMessage: {
        type: 'Body should be object.',
        properties: {
          email: 'Email must be an email valid.',
          password: 'Password it must be a string with length at least 6 chars long.',
          fName: 'First Name it must be a string.',
          lName: 'Last Name it must be a string.',
          bidCurrency: 'Bid Currency it must be a string.',
          otherSystemReference: 'Other System Reference it must be a string.',
          companyName: 'Company Name it must be a string.',
          origin: 'Origin it must be a string.',
          address: 'Address it must be a string.',
          originPostalCode: 'Origin Postal Code it must be a string.',
          originLocality: 'Origin Locality it must be a string.',
          originSublocalityLevel2: 'Origin Sublocality Level 2 it must be a string.',
          originAdministrativeAreaLevel1: 'Origin Administrative Area Level 1 it must be a string.',
          originAdministrativeAreaLevel1Short: 'Origin Administrative Area Level 1 Short it must be a string.',
          originCountry: 'Origin Country it must be a string.',
          originCountryShort: 'Origin Country Short it must be a string.',
          originLat: 'Origin Lat Short it must be a string.',
          originLng: 'Origin Lng Short it must be a string.',
          contactno: 'Contact Number it must be a string.',
          fax: 'Fax it must be a string.',
          databaseName: 'Database Name it must be a string.'
        }
      },
      required: ['email', 'password', 'fName', 'lName', 'bidCurrency', 'companyName', 'origin', 'address', 'originPostalCode', 'originLocality', 'originSublocalityLevel2', 'originAdministrativeAreaLevel1', 'originAdministrativeAreaLevel1Short', 'originCountry', 'originCountryShort', 'originLat', 'originLng', 'contactno', 'databaseName']
    }
  }
}

/**
 * Running validations imperatively.
 *
 * @param {Object} schema Schema of validations on the request.
 * @param {Object} event Input event to the Lambda function.
 * @returns {Promise.<void>}
 */
const validate = async (schema, event) => {
  logger.i(`Input event: ${utils.serialize(event)}`)
  event.body = utils.deserialize(event.body)
  await utils.validate(schema, event)
}

module.exports = { validate, schema }
