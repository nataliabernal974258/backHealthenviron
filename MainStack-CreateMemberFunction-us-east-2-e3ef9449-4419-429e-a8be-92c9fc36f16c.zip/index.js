'use strict'

const { auth, utils, logger, mariadb } = require('@cornerstonesln/tools-nodejs-backend')
const Member = require('./member')
const { validate, schema } = require('./validations')
// const { importCloudSQL } = require('./helpers')

const { isAuthenticated } = auth
const { handleWithError, formatError, formatResponse, getConnection } = utils

let connection
// Connects to a connection pool to the MariaDB database.
if (typeof connection === 'undefined') connection = mariadb.createPool(getConnection())

// TODO: Lambda Function must be fix.

/**
 * Create a new member.
 *
 * @param {Object} event Input event to the Lambda function.
 * @param {Object} event.body HTTP request body.
 * @param {Object} event.body.email Email address.
 * @param {string} event.body.password Password.
 * @param {string} event.body.fName First name.
 * @param {string} event.body.lName Last name.
 * @param {string} event.body.bidCurrency BID currency.
 * @param {string} [event.body.otherSystemReference] Other system reference ID: SAP System Reference ID
 * @param {string} event.body.companyName Company Name.
 * @param {string} event.body.origin Address Google.
 * @param {string} event.body.address Address.
 * @param {string} event.body.originPostalCode Zip code.
 * @param {string} event.body.originLocality City.
 * @param {string} event.body.originSublocalityLevel2 District.
 * @param {string} event.body.originAdministrativeAreaLevel1 State.
 * @param {string} event.body.originAdministrativeAreaLevel1Short State ISO 2.
 * @param {string} event.body.originCountry Country.
 * @param {string} event.body.originCountryShort Country ISO 2.
 * @param {string} event.body.originLat Latitude
 * @param {string} event.body.originLng Longitude
 * @param {string} event.body.contactno Contact number.
 * @param {string} [event.body.fax] Fax number
 * @param {string} event.body.databaseName Database name.
 */
 
exports.createMemberHandler  = async (event) => {
  try {
    await validate(schema, event)
    await isAuthenticated(event, 'x-healthenviron-api-key')
    const { body } = event

    const repository = new Member(connection)

    // Database validations.
    const isEmailExists = await repository.isEmailExists(body.email)
    if (isEmailExists) handleWithError(422, 'Email already in use.')

    const isDatabaseNameExists = await repository.isDatabaseNameExists(body.databaseName)
    if (isDatabaseNameExists) handleWithError(422, 'Database Name already in use.')

    const member = repository.toDatabase(body, event.member.id)

    const result = await repository.create(member.member, member.address, member.database_name)
    // if (result) await importCloudSQL(body.databaseName)

    const response = result
      ? formatResponse(201, 'Successfully created new member.', result)
      : formatResponse(500, 'An error occurred while trying to create a new member.')

    return response
  } catch (error) {
    logger.e(error.message, error)
    return formatError(error)
  }
}
