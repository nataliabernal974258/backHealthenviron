// 'use strict'

// const { google } = require('googleapis')
// const { utils, logger } = require('@cornerstonesln/tools-nodejs-backend')

// const { handleWithError } = utils
// const sqladmin = google.sqladmin('v1beta4')

// const INSTANCE_ID = 'americas'
// const PROJECT_ID = 'barcode-scanning-platform'

// /**
//  * Import Cloud SQL.
//  *
//  * @param {string} databaseName The database name.
//  * @return {Promise.<void>}
//  */
// async function importCloudSQL (databaseName) {
//   try {
//     const auth = new google.auth.GoogleAuth({
//       // Scopes can be specified either as an array or as a single, space-delimited string.
//       scopes: [
//         'https://www.googleapis.com/auth/cloud-platform',
//         'https://www.googleapis.com/auth/sqlservice.admin'
//       ]
//     })

//     // Acquire an auth client, and bind it to all future calls
//     const authClient = await auth.getClient()
//     google.options({ auth: authClient })

//     await sqladmin.instances.import({
//       // Cloud SQL instance ID. This does not include the project ID.
//       instance: INSTANCE_ID,
//       // Project ID of the project that contains the instance.
//       project: PROJECT_ID,
//       // Request body metadata
//       requestBody: {
//         // request body parameters
//         importContext: {
//           kind: 'sql#importContext',
//           database: databaseName,
//           fileType: 'SQL',
//           uri: 'gs://healthenviron_main/database_templates/database.sql'
//         }
//       }
//     })
//   } catch (error) {
//     const code = error.code || 500
//     handleWithError(code, 'An error occurred while importing the database template file.', error.errors)
//   }
// }

// module.exports = { importCloudSQL }
